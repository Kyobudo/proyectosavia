
package Getset;


public class GetSet {
     public String numero_factura;
     public String nit;
     public String prueba;
     public int cm_detalles_id;

    public int getCm_detalles_id() {
        return cm_detalles_id;
    }

    public void setCm_detalles_id(int cm_detalles_id) {
        this.cm_detalles_id = cm_detalles_id;
    }

    public String getNumero_factura() {
        return numero_factura;
    }

    public void setNumero_factura(String numero_factura) {
        this.numero_factura = numero_factura;
    }

    public String getNit() {
        return nit;
    }

    public void setNit(String nit) {
        this.nit = nit;
    }

    public String getPrueba() {
        return prueba;
    }

    public void setPrueba(String prueba) {
        this.prueba = prueba;
    }

    
}
